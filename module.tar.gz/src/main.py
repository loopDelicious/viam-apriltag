import asyncio
import sys
from typing import ClassVar, Final, List, Mapping, Optional, Sequence

from typing_extensions import Self
from viam.media.video import ViamImage
from viam.module.module import Module
from viam.proto.app.robot import ComponentConfig
from viam.proto.common import PointCloudObject, ResourceName
from viam.proto.service.vision import (Classification, Detection,
                                       GetPropertiesResponse)
from viam.resource.base import ResourceBase
from viam.resource.easy_resource import EasyResource
from viam.resource.types import Model, ModelFamily
from viam.services.vision import *
from viam.utils import ValueTypes
from viam.logging import getLogger
from viam.media.utils.pil import viam_to_pil_image
from PIL import Image
import numpy as np
import cv2
import apriltag
import time

LOGGER = getLogger(__name__)

class Apriltag(Vision, EasyResource):
    MODEL: ClassVar[Model] = Model(ModelFamily("joyce", "vision"), "apriltag")

    model: None

    last_triggered: dict = {}

    cooldown_period: int = 5
    
        @classmethod
    def new(cls, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]) -> Self:
        my_class = cls(config.name)
        my_class.reconfigure(config, dependencies)
        return my_class

    # Validates JSON Configuration
    @classmethod
    def validate(cls, config: ComponentConfig):
        return

    # Handles attribute reconfiguration
    def reconfigure(self, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]):
        self.DEPS = dependencies
        return
        
    async def get_cam_image(self, camera_name: str) -> ViamImage:
        actual_cam = self.DEPS[Camera.get_resource_name(camera_name)]
        cam = cast(Camera, actual_cam)
        cam_image = await cam.get_image(mime_type="image/jpeg")
        return cam_image

    async def get_detections_from_camera(self, camera_name: str, *, extra: Optional[Mapping[str, Any]] = None, timeout: Optional[float] = None) -> List[Detection]:
        # Get image from the camera
        cam_image = await self.get_cam_image(camera_name)
        return await self.detect_april_tag(cam_image)

    async def get_detections(
        self,
        image: Image.Image,
        *,
        extra: Optional[Mapping[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> List[Detection]:
        # Convert PIL image to ViamImage or OpenCV as needed
        image_cv = np.array(image)
        image_cv = cv2.cvtColor(image_cv, cv2.COLOR_RGB2BGR)
        return self.detect_april_tag(ViamImage(data=image_cv.tobytes(), mime_type="image/jpeg"))

    async def get_classifications(
        self,
        image: Image.Image,
        count: int,
        *,
        extra: Optional[Mapping[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> List[Classification]:
        """
        This method is not implemented for Apriltag detection.
        """
        # No classifications are done, return an empty list
        return []

    async def detect_april_tag(self, image: ViamImage) -> List[Detection]:
        """
        Detect April Tags in the given image using apriltag.
        """
        # Convert ViamImage to OpenCV format
        image_pil = viam_to_pil_image(image)
        image_cv = np.array(image_pil)
        image_cv = cv2.cvtColor(image_cv, cv2.COLOR_RGB2GRAY)  # Convert to grayscale for apriltag

        # Detect April Tags using AprilTag
        detector = apriltag.Detector()
        tags = detector.detect(image_cv)
        detections = []

        for tag in tags:
            tag_data = tag.tag_id
            LOGGER.info(f"AprilTag detected: {tag_data}")

            # Only trigger action if it hasn't been triggered recently
            current_time = time.time()
            if tag_data not in self.last_triggered or (current_time - self.last_triggered[tag_data] > self.cooldown_period):
                self.trigger_action_on_april_tag(str(tag_data))
                self.last_triggered[tag_data] = current_time

            # Create a Detection object for each tag detected
            (x, y, w, h) = tag.rect  # Get bounding box
            detection = Detection(x_min=int(x), y_min=int(y), x_max=int(x + w), y_max=int(y + h), class_name=str(tag_data), confidence=1.0)
            detections.append(detection)

        if not tags:
            LOGGER.info("No April Tags detected")

        return detections
    
    def preprocess_image(self, image):
        """
        Preprocess the image to improve Apriltag detection.
        """
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        equalized_image = cv2.equalizeHist(gray_image)
        threshold_image = cv2.threshold(equalized_image, 128, 255, cv2.THRESH_BINARY)[1]
        resized_image = cv2.resize(threshold_image, None, fx=1.5, fy=1.5, interpolation=cv2.INTER_LINEAR)
        return resized_image
    
    def trigger_action_on_april_tag(self, april_tag_data: str):
        """
        Trigger an action based on the AprilTag data.
        """
        
        # Can add custom logic here
        LOGGER.info(f"Triggering action based on April Tag: {april_tag_data}")

    async def get_classifications_from_camera(self, camera_name: str, count: int, *, extra: Optional[Mapping[str, Any]] = None, timeout: Optional[float] = None) -> List[Classification]:
        """
        This method is not implemented for Apriltag detection.
        """
        return []
    
    async def get_object_point_clouds(self, camera_name: str, *, extra: Optional[Mapping[str, Any]] = None, timeout: Optional[float] = None) -> List[PointCloudObject]:
        return []
    
    async def do_command(self, command: Mapping[str, ValueTypes], *, timeout: Optional[float] = None) -> Mapping[str, ValueTypes]:
        return {}

    async def capture_all_from_camera(self, camera_name: str, return_image: bool = False, return_classifications: bool = False, return_detections: bool = False, return_object_point_clouds: bool = False, *, extra: Optional[Mapping[str, Any]] = None, timeout: Optional[float] = None) -> CaptureAllResult:
        result = CaptureAllResult()
        result.image = await self.get_cam_image(camera_name)
        result.detections = await self.get_detections_from_camera(camera_name)
        return result

    async def get_properties(self, *, extra: Optional[Mapping[str, Any]] = None, timeout: Optional[float] = None) -> GetPropertiesResponse:
        return GetPropertiesResponse(
            classifications_supported=False,
            detections_supported=True,
            object_point_clouds_supported=False
        )

if __name__ == "__main__":
    asyncio.run(Module.run_from_registry())

